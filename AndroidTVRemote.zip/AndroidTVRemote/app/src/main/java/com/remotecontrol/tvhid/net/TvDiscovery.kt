package com.remotecontrol.tvhid.net

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.os.Build
import android.util.Log

data class DiscoveredTv(
    val name: String,
    val host: String,
    val port: Int
)

/**
 * Browses for Android TV / Google TV devices advertising
 * _androidtvremote2._tcp on the local network.
 */
class TvDiscovery(private val context: Context) {

    interface Listener {
        fun onFound(tv: DiscoveredTv)
        fun onLost(name: String)
    }

    private val nsdManager by lazy { context.getSystemService(Context.NSD_SERVICE) as NsdManager }
    private var discoveryListener: NsdManager.DiscoveryListener? = null

    fun start(listener: Listener) {
        val resolveListener = object : NsdManager.ResolveListener {
            override fun onResolveFailed(serviceInfo: NsdServiceInfo?, errorCode: Int) {
                Log.w(TAG, "Resolve failed for ${serviceInfo?.serviceName}: $errorCode")
            }

            override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                val host = serviceInfo.host?.hostAddress ?: return
                listener.onFound(DiscoveredTv(serviceInfo.serviceName, host, serviceInfo.port))
            }
        }

        val listenerImpl = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) {}
            override fun onDiscoveryStopped(serviceType: String) {}
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                Log.w(TAG, "Start discovery failed: $errorCode")
            }
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}

            override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                try {
                    if (Build.VERSION.SDK_INT >= 34) {
                        nsdManager.resolveService(serviceInfo, context.mainExecutor, resolveListener)
                    } else {
                        @Suppress("DEPRECATION")
                        nsdManager.resolveService(serviceInfo, resolveListener)
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "resolveService threw", e)
                }
            }

            override fun onServiceLost(serviceInfo: NsdServiceInfo) {
                listener.onLost(serviceInfo.serviceName)
            }
        }

        discoveryListener = listenerImpl
        nsdManager.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, listenerImpl)
    }

    fun stop() {
        discoveryListener?.let {
            try { nsdManager.stopServiceDiscovery(it) } catch (_: Exception) {}
        }
        discoveryListener = null
    }

    companion object {
        private const val TAG = "TvDiscovery"
        private const val SERVICE_TYPE = "_androidtvremote2._tcp."
    }
}
