package com.remotecontrol.tvhid

/**
 * USB HID Usage Tables (keyboard page 0x07) — the codes the TV's HID host
 * expects inside a standard 8-byte keyboard report.
 * Report layout: [modifierByte, reserved, key1, key2, key3, key4, key5, key6]
 */
object KeyCode {
    const val NONE = 0x00
    const val ENTER = 0x28
    const val ESCAPE = 0x29        // Mapped to "Back" on most Android TV HID hosts
    const val BACKSPACE = 0x2A
    const val RIGHT_ARROW = 0x4F
    const val LEFT_ARROW = 0x50
    const val DOWN_ARROW = 0x51
    const val UP_ARROW = 0x52

    // Modifier bitmask (byte 0 of the keyboard report)
    const val MOD_NONE = 0x00
}

/**
 * Consumer Page (0x0C) usage codes, sent as a single-bit bitmap in the
 * 1-byte Consumer Control report (Report ID 3). Each bit corresponds to
 * one usage declared in the HID report descriptor, in the same order.
 */
object ConsumerBit {
    const val VOLUME_UP = 1 shl 0
    const val VOLUME_DOWN = 1 shl 1
    const val MUTE = 1 shl 2
    const val PLAY_PAUSE = 1 shl 3
    const val NEXT_TRACK = 1 shl 4
    const val PREV_TRACK = 1 shl 5
    const val MENU = 1 shl 6      // Some TVs treat "Menu" as a settings/options key
    const val AC_HOME = 1 shl 7   // "AL Home" — works on many, not all, Android TV HID hosts
}

/** Mouse button bits for the mouse report (byte 0). */
object MouseButton {
    const val LEFT = 1 shl 0
    const val RIGHT = 1 shl 1
    const val MIDDLE = 1 shl 2
}

/** Report IDs used across the composite HID descriptor. */
object ReportId {
    const val KEYBOARD = 1
    const val MOUSE = 2
    const val CONSUMER = 3
}
