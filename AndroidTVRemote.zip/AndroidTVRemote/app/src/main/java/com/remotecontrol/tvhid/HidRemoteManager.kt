package com.remotecontrol.tvhid

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothHidDevice
import android.bluetooth.BluetoothHidDeviceAppQosSettings
import android.bluetooth.BluetoothHidDeviceAppSdpSettings
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import androidx.core.app.ActivityCompat
import java.util.concurrent.Executor

/**
 * Wraps Android's BluetoothHidDevice profile so the phone registers itself as
 * a composite Bluetooth HID device (keyboard + mouse + consumer control).
 * Once connected, the TV sees this phone exactly like it would see a
 * Bluetooth remote/mouse combo.
 *
 * NOTE: This is a system-level profile. It requires the phone to pair with
 * the TV; the TV must be put into "pair new remote/accessory" mode (or you
 * initiate the connection from the phone to an already-bonded TV).
 */
class HidRemoteManager(private val context: Context) {

    interface Listener {
        fun onAppRegistered(success: Boolean)
        fun onConnectionStateChanged(device: BluetoothDevice?, state: Int)
    }

    var listener: Listener? = null
    private var hidDevice: BluetoothHidDevice? = null
    private var connectedDevice: BluetoothDevice? = null
    private val mainExecutor: Executor = Executor { command -> command.run() }

    private val serviceListener = object : BluetoothProfile.ServiceListener {
        override fun onServiceConnected(profile: Int, proxy: BluetoothProfile) {
            if (profile == BluetoothProfile.HID_DEVICE) {
                hidDevice = proxy as BluetoothHidDevice
                registerApp()
            }
        }

        override fun onServiceDisconnected(profile: Int) {
            if (profile == BluetoothProfile.HID_DEVICE) {
                hidDevice = null
            }
        }
    }

    private val hidCallback = object : BluetoothHidDevice.Callback() {
        override fun onAppStatusChanged(pluggedDevice: BluetoothDevice?, registered: Boolean) {
            Log.d(TAG, "onAppStatusChanged registered=$registered")
            listener?.onAppRegistered(registered)
        }

        override fun onConnectionStateChanged(device: BluetoothDevice?, state: Int) {
            Log.d(TAG, "onConnectionStateChanged state=$state device=${device?.address}")
            connectedDevice = if (state == BluetoothProfile.STATE_CONNECTED) device else null
            listener?.onConnectionStateChanged(device, state)
        }

        override fun onGetReport(
            device: BluetoothDevice?,
            type: Byte,
            id: Byte,
            bufferSize: Int
        ) {
            // Host asked us to resend current state; reply with an all-zero
            // (idle) report of the right size so the connection stays healthy.
            hidDevice?.replyReport(device, type, id, ByteArray(bufferSize.coerceAtLeast(1)))
        }

        override fun onSetReport(device: BluetoothDevice?, type: Byte, id: Byte, data: ByteArray?) {
            // Host -> device reports (e.g. keyboard LEDs). Nothing to do.
        }
    }

    /** Call once, e.g. from Activity.onCreate, to start the HID_DEVICE profile proxy. */
    fun start() {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: run {
            listener?.onAppRegistered(false)
            return
        }
        adapter.getProfileProxy(context, serviceListener, BluetoothProfile.HID_DEVICE)
    }

    fun stop() {
        connectedDevice?.let { unregisterAndDisconnect(it) }
        hidDevice = null
    }

    private fun hasConnectPermission(): Boolean {
        return if (android.os.Build.VERSION.SDK_INT >= 31) {
            ActivityCompat.checkSelfPermission(
                context, Manifest.permission.BLUETOOTH_CONNECT
            ) == PackageManager.PERMISSION_GRANTED
        } else true
    }

    private fun registerApp() {
        if (!hasConnectPermission()) return

        val qos = BluetoothHidDeviceAppQosSettings(
            BluetoothHidDeviceAppQosSettings.SERVICE_GUARANTEED,
            800, 9, 0, 11250, 11250
        )

        val sdp = BluetoothHidDeviceAppSdpSettings(
            "Phone TV Remote",                     // Name shown on the TV's Bluetooth device list
            "Keyboard, mouse & media remote",       // Description
            "Anthropic Sample",                     // Provider
            BluetoothHidDevice.SUBCLASS1_COMBO,     // Combo keyboard/pointer device
            HID_REPORT_DESCRIPTOR
        )

        hidDevice?.registerApp(sdp, null, qos, mainExecutor, hidCallback)
    }

    /** Connect to a device that is already bonded (paired) with this phone. */
    fun connect(device: BluetoothDevice) {
        if (!hasConnectPermission()) return
        hidDevice?.connect(device)
    }

    fun disconnect(device: BluetoothDevice) {
        if (!hasConnectPermission()) return
        hidDevice?.disconnect(device)
    }

    private fun unregisterAndDisconnect(device: BluetoothDevice) {
        if (!hasConnectPermission()) return
        hidDevice?.disconnect(device)
        hidDevice?.unregisterApp()
    }

    // ---- Report senders -----------------------------------------------

    fun sendKey(keyCode: Int, modifier: Int = KeyCode.MOD_NONE) {
        val device = connectedDevice ?: return
        if (!hasConnectPermission()) return
        val down = byteArrayOf(modifier.toByte(), 0x00, keyCode.toByte(), 0, 0, 0, 0, 0)
        val up = ByteArray(8)
        hidDevice?.sendReport(device, ReportId.KEYBOARD, down)
        hidDevice?.sendReport(device, ReportId.KEYBOARD, up)
    }

    fun sendConsumer(bit: Int) {
        val device = connectedDevice ?: return
        if (!hasConnectPermission()) return
        hidDevice?.sendReport(device, ReportId.CONSUMER, byteArrayOf(bit.toByte()))
        hidDevice?.sendReport(device, ReportId.CONSUMER, byteArrayOf(0x00))
    }

    /** dx/dy/wheel are relative deltas in range -127..127. */
    fun sendMouseMove(dx: Int, dy: Int, wheel: Int = 0, buttons: Int = 0) {
        val device = connectedDevice ?: return
        if (!hasConnectPermission()) return
        val report = byteArrayOf(
            buttons.toByte(),
            dx.coerceIn(-127, 127).toByte(),
            dy.coerceIn(-127, 127).toByte(),
            wheel.coerceIn(-127, 127).toByte()
        )
        hidDevice?.sendReport(device, ReportId.MOUSE, report)
    }

    fun sendMouseClick(button: Int) {
        val device = connectedDevice ?: return
        if (!hasConnectPermission()) return
        hidDevice?.sendReport(device, ReportId.MOUSE, byteArrayOf(button.toByte(), 0, 0, 0))
        hidDevice?.sendReport(device, ReportId.MOUSE, byteArrayOf(0, 0, 0, 0))
    }

    fun isConnected(): Boolean = connectedDevice != null

    companion object {
        private const val TAG = "HidRemoteManager"

        /**
         * Composite HID report descriptor: keyboard (Report ID 1),
         * mouse (Report ID 2), and an 8-bit consumer-control bitmap
         * (Report ID 3). Written by hand per the USB HID spec — if a
         * particular TV/box behaves oddly, this is the first thing to
         * inspect/adjust.
         */
        private val HID_REPORT_DESCRIPTOR: ByteArray = byteArrayOf(
            // ---- Keyboard collection (Report ID 1) ----
            0x05, 0x01,             // Usage Page (Generic Desktop)
            0x09, 0x06,             // Usage (Keyboard)
            0xA1.toByte(), 0x01,    // Collection (Application)
            0x85.toByte(), 0x01,    //   Report ID (1)
            0x05, 0x07,             //   Usage Page (Key Codes)
            0x19, 0xE0.toByte(),    //   Usage Minimum (224 = LeftControl)
            0x29, 0xE7.toByte(),    //   Usage Maximum (231 = RightGUI)
            0x15, 0x00,             //   Logical Minimum (0)
            0x25, 0x01,             //   Logical Maximum (1)
            0x75, 0x01,             //   Report Size (1)
            0x95.toByte(), 0x08,    //   Report Count (8)  -> modifier byte
            0x81.toByte(), 0x02,    //   Input (Data, Var, Abs)
            0x95.toByte(), 0x01,    //   Report Count (1)
            0x75, 0x08,             //   Report Size (8)   -> reserved byte
            0x81.toByte(), 0x01,    //   Input (Const)
            0x95.toByte(), 0x06,    //   Report Count (6)  -> up to 6 keys
            0x75, 0x08,             //   Report Size (8)
            0x15, 0x00,             //   Logical Minimum (0)
            0x25, 0x65,             //   Logical Maximum (101)
            0x05, 0x07,             //   Usage Page (Key Codes)
            0x19, 0x00,             //   Usage Minimum (0)
            0x29, 0x65,             //   Usage Maximum (101)
            0x81.toByte(), 0x00,    //   Input (Data, Array)
            0xC0.toByte(),          // End Collection

            // ---- Mouse collection (Report ID 2) ----
            0x05, 0x01,             // Usage Page (Generic Desktop)
            0x09, 0x02,             // Usage (Mouse)
            0xA1.toByte(), 0x01,    // Collection (Application)
            0x85.toByte(), 0x02,    //   Report ID (2)
            0x09, 0x01,             //   Usage (Pointer)
            0xA1.toByte(), 0x00,    //   Collection (Physical)
            0x05, 0x09,             //     Usage Page (Buttons)
            0x19, 0x01,             //     Usage Minimum (Button 1)
            0x29, 0x03,             //     Usage Maximum (Button 3)
            0x15, 0x00,             //     Logical Minimum (0)
            0x25, 0x01,             //     Logical Maximum (1)
            0x95.toByte(), 0x03,    //     Report Count (3)
            0x75, 0x01,             //     Report Size (1)
            0x81.toByte(), 0x02,    //     Input (Data, Var, Abs)
            0x95.toByte(), 0x01,    //     Report Count (1)
            0x75, 0x05,             //     Report Size (5)  -> padding
            0x81.toByte(), 0x01,    //     Input (Const)
            0x05, 0x01,             //     Usage Page (Generic Desktop)
            0x09, 0x30,             //     Usage (X)
            0x09, 0x31,             //     Usage (Y)
            0x09, 0x38,             //     Usage (Wheel)
            0x15, 0x81.toByte(),    //     Logical Minimum (-127)
            0x25, 0x7F,             //     Logical Maximum (127)
            0x75, 0x08,             //     Report Size (8)
            0x95.toByte(), 0x03,    //     Report Count (3)
            0x81.toByte(), 0x06,    //     Input (Data, Var, Relative)
            0xC0.toByte(),          //   End Collection
            0xC0.toByte(),          // End Collection

            // ---- Consumer control collection (Report ID 3) ----
            0x05, 0x0C,             // Usage Page (Consumer)
            0x09, 0x01,             // Usage (Consumer Control)
            0xA1.toByte(), 0x01,    // Collection (Application)
            0x85.toByte(), 0x03,    //   Report ID (3)
            0x15, 0x00,             //   Logical Minimum (0)
            0x25, 0x01,             //   Logical Maximum (1)
            0x75, 0x01,             //   Report Size (1)
            0x95.toByte(), 0x08,    //   Report Count (8) -> one bit per usage below
            0x09, 0xE9.toByte(),    //   Usage (Volume Increment)      bit 0
            0x09, 0xEA.toByte(),    //   Usage (Volume Decrement)      bit 1
            0x09, 0xE2.toByte(),    //   Usage (Mute)                  bit 2
            0x09, 0xCD.toByte(),    //   Usage (Play/Pause)            bit 3
            0x09, 0xB5.toByte(),    //   Usage (Scan Next Track)       bit 4
            0x09, 0xB6.toByte(),    //   Usage (Scan Previous Track)   bit 5
            0x09, 0x40,             //   Usage (Menu)                  bit 6
            0x0A, 0x23, 0x02,       //   Usage (AL Home, 2-byte usage) bit 7
            0x81.toByte(), 0x02,    //   Input (Data, Var, Abs)
            0xC0.toByte()           // End Collection
        )
    }
}
