package com.remotecontrol.tvhid.net

import java.math.BigInteger
import java.security.KeyStore
import java.security.MessageDigest
import java.security.cert.X509Certificate
import java.security.interfaces.RSAPublicKey
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.X509TrustManager

/**
 * The pairing code on screen is what proves to the TV that the phone that's
 * connecting is the one the user is looking at — not a certificate chain. So
 * we deliberately trust the TV's self-signed certificate unconditionally
 * here; trust is established afterwards via the 6-digit code exchange.
 */
class TrustAllTrustManager : X509TrustManager {
    var lastSeenServerCert: X509Certificate? = null
        private set

    override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}

    override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {
        lastSeenServerCert = chain?.firstOrNull()
    }

    override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
}

object TlsSupport {

    /** Builds an SSLContext presenting [identity]'s cert/key and trusting whatever the TV presents. */
    fun buildContext(identity: ClientIdentity, trustManager: TrustAllTrustManager): SSLContext {
        val keyStore = KeyStore.getInstance("PKCS12")
        keyStore.load(null, null)
        keyStore.setKeyEntry(
            "client", identity.privateKey, charArrayOf(),
            arrayOf(identity.certificate)
        )

        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(keyStore, charArrayOf())

        val context = SSLContext.getInstance("TLSv1.2")
        context.init(kmf.keyManagers, arrayOf(trustManager), null)
        return context
    }

    /**
     * Pairing secret per the Android TV Remote v2 protocol:
     *   SHA256(clientModulus || clientExponent || serverModulus || serverExponent || codeNonce)
     * where codeNonce is the last 2 bytes of the 3-byte (6 hex char) code the
     * TV displays, and the first byte of that code is a checksum which must
     * equal the first byte of this SHA-256 digest.
     *
     * Returns null if the checksum doesn't match (almost always a typo).
     */
    fun computeSecret(
        clientCert: X509Certificate,
        serverCert: X509Certificate,
        sixDigitHexCode: String
    ): ByteArray? {
        val codeBytes = hexToBytes(sixDigitHexCode)
        if (codeBytes.size != 3) return null
        val checksum = codeBytes[0]
        val nonce = codeBytes.copyOfRange(1, 3)

        val clientKey = clientCert.publicKey as RSAPublicKey
        val serverKey = serverCert.publicKey as RSAPublicKey

        val digest = MessageDigest.getInstance("SHA-256")
        digest.update(unsignedBytes(clientKey.modulus))
        digest.update(unsignedBytes(clientKey.publicExponent))
        digest.update(unsignedBytes(serverKey.modulus))
        digest.update(unsignedBytes(serverKey.publicExponent))
        digest.update(nonce)
        val hash = digest.digest()

        if (hash[0] != checksum) return null
        return hash
    }

    private fun unsignedBytes(value: BigInteger): ByteArray {
        // BigInteger.toByteArray() is two's-complement and may include a
        // leading 0x00 sign byte; that's fine and matches what the reference
        // Java-based pairing implementation produces from the same API.
        return value.toByteArray()
    }

    private fun hexToBytes(hex: String): ByteArray {
        val clean = hex.trim()
        require(clean.length % 2 == 0) { "Pairing code must have an even number of hex digits" }
        return ByteArray(clean.length / 2) { i ->
            ((Character.digit(clean[i * 2], 16) shl 4) + Character.digit(clean[i * 2 + 1], 16)).toByte()
        }
    }
}
