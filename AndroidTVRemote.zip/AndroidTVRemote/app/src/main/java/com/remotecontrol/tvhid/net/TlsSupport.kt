package com.remotecontrol.tvhid.net

import java.math.BigInteger
import java.security.KeyStore
import java.security.MessageDigest
import java.security.cert.X509Certificate
import java.security.interfaces.RSAPublicKey
import javax.net.ssl.KeyManagerFactory
import javax.net.ssl.SSLContext
import javax.net.ssl.X509TrustManager

/**
 * The pairing code on screen is what proves to the TV that the phone that's
 * connecting is the one the user is looking at — not a certificate chain. So
 * we deliberately trust the TV's self-signed certificate unconditionally
 * here; trust is established afterwards via the 6-digit code exchange.
 */
class TrustAllTrustManager : X509TrustManager {
    var lastSeenServerCert: X509Certificate? = null
        private set

    override fun checkClientTrusted(chain: Array<out X509Certificate>?, authType: String?) {}

    override fun checkServerTrusted(chain: Array<out X509Certificate>?, authType: String?) {
        lastSeenServerCert = chain?.firstOrNull()
    }

    override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
}

object TlsSupport {

    /** Builds an SSLContext presenting [identity]'s cert/key and trusting whatever the TV presents. */
    fun buildContext(identity: ClientIdentity, trustManager: TrustAllTrustManager): SSLContext {
        val keyStore = KeyStore.getInstance("PKCS12")
        keyStore.load(null, null)
        keyStore.setKeyEntry(
            "client", identity.privateKey, charArrayOf(),
            arrayOf(identity.certificate)
        )

        val kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm())
        kmf.init(keyStore, charArrayOf())

        val context = SSLContext.getInstance("TLSv1.2")
        context.init(kmf.keyManagers, arrayOf(trustManager), null)
        return context
    }

    /**
     * Pairing secret per the Android TV Remote v2 protocol:
     *   SHA256(clientModulus || clientExponent || serverModulus || serverExponent || codeNonce)
     * where codeNonce is the last 2 bytes of the 3-byte (6 hex char) code the
     * TV displays, and the first byte of that code is a checksum which must
     * equal the first byte of this SHA-256 digest.
     *
     * The reference implementations hash the numbers as minimal unsigned
     * big-endian bytes (no 0x00 sign byte). We try that first, then the signed
     * two's-complement form as a fallback, and accept whichever passes the checksum.
     *
     * Returns null if neither passes (a genuine typo).
     */
    fun computeSecret(
        clientCert: X509Certificate,
        serverCert: X509Certificate,
        sixDigitHexCode: String
    ): ByteArray? {
        val codeBytes = try { hexToBytes(sixDigitHexCode) } catch (_: Exception) { return null }
        if (codeBytes.size != 3) return null
        val checksum = codeBytes[0]
        val nonce = codeBytes.copyOfRange(1, 3)

        val clientKey = clientCert.publicKey as RSAPublicKey
        val serverKey = serverCert.publicKey as RSAPublicKey

        val encoders: List<(BigInteger) -> ByteArray> = listOf(
            { v -> unsignedBytes(v) },
            { v -> v.toByteArray() }
        )
        for (encode in encoders) {
            val digest = MessageDigest.getInstance("SHA-256")
            digest.update(encode(clientKey.modulus))
            digest.update(encode(clientKey.publicExponent))
            digest.update(encode(serverKey.modulus))
            digest.update(encode(serverKey.publicExponent))
            digest.update(nonce)
            val hash = digest.digest()
            if (hash[0] == checksum) return hash
        }
        return null
    }

    /** Minimal unsigned big-endian bytes: BigInteger.toByteArray() without the leading sign byte. */
    private fun unsignedBytes(value: BigInteger): ByteArray {
        val bytes = value.toByteArray()
        return if (bytes.size > 1 && bytes[0] == 0.toByte()) bytes.copyOfRange(1, bytes.size) else bytes
    }

    private fun hexToBytes(hex: String): ByteArray {
        val clean = hex.trim()
        require(clean.length % 2 == 0) { "Pairing code must have an even number of hex digits" }
        return ByteArray(clean.length / 2) { i ->
            ((Character.digit(clean[i * 2], 16) shl 4) + Character.digit(clean[i * 2 + 1], 16)).toByte()
        }
    }
}
