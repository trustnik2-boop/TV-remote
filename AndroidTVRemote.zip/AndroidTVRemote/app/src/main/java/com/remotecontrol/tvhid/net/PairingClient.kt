package com.remotecontrol.tvhid.net

import android.os.Build
import com.remotecontrol.tvhid.proto.Polo
import java.io.DataInputStream
import java.io.DataOutputStream
import java.security.cert.X509Certificate
import javax.net.ssl.SSLSocket
import kotlin.concurrent.thread

/**
 * Runs the pairing (Polo) handshake with a TV over TLS on port 6467.
 * Call [begin] first; once the TV is showing its code, call [submitCode].
 */
class PairingClient(
    private val host: String,
    private val port: Int,
    private val identity: ClientIdentity
) {
    interface Listener {
        fun onCodeNeeded()
        fun onPaired()
        fun onFailed(message: String)
    }

    private var socket: SSLSocket? = null
    private var input: DataInputStream? = null
    private var output: DataOutputStream? = null
    private var serverCert: X509Certificate? = null
    private var listener: Listener? = null

    fun begin(listener: Listener) {
        this.listener = listener
        thread(name = "pairing") {
            try {
                runHandshakeUntilCodeNeeded()
            } catch (e: Exception) {
                listener.onFailed(e.message ?: e.toString())
            }
        }
    }

    private fun runHandshakeUntilCodeNeeded() {
        val trustManager = TrustAllTrustManager()
        val context = TlsSupport.buildContext(identity, trustManager)
        val factory = context.socketFactory
        val sock = factory.createSocket(host, port) as SSLSocket
        sock.startHandshake()
        serverCert = trustManager.lastSeenServerCert
        socket = sock
        input = DataInputStream(sock.inputStream)
        output = DataOutputStream(sock.outputStream)

        // Initialization phase
        sendOuter(Polo.TYPE_PAIRING_REQUEST, Polo.pairingRequest("androidtv-remote", Build.MODEL ?: "Phone"))
        val ack = readOuter()
        check(ack.type == Polo.TYPE_PAIRING_REQUEST_ACK) { "Unexpected reply to pairing request (${ack.debug})" }

        // Configuration phase
        sendOuter(Polo.TYPE_OPTIONS, Polo.options())
        readOuter() // server's Options; we only support one encoding so nothing to negotiate

        sendOuter(Polo.TYPE_CONFIGURATION, Polo.configuration())
        val configAck = readOuter()
        check(configAck.type == Polo.TYPE_CONFIGURATION_ACK) { "TV rejected configuration (${configAck.debug})" }

        // TV is now showing the code on screen.
        listener?.onCodeNeeded()
    }

    /** Call once the user has typed in the 6-character hex code shown on the TV. */
    fun submitCode(code: String) {
        thread(name = "pairing-secret") {
            try {
                val server = serverCert ?: error("No server certificate captured")
                val secret = TlsSupport.computeSecret(identity.certificate, server, code)
                    ?: run { listener?.onFailed("Code doesn't match — check for a typo"); return@thread }

                sendOuter(Polo.TYPE_SECRET, Polo.secret(secret))
                val ack = readOuter()
                if (ack.status == Polo.STATUS_OK) {
                    listener?.onPaired()
                } else {
                    listener?.onFailed("TV rejected the pairing secret (status ${ack.status})")
                }
            } catch (e: Exception) {
                listener?.onFailed(e.message ?: e.toString())
            } finally {
                close()
            }
        }
    }

    fun close() {
        try { socket?.close() } catch (_: Exception) {}
    }

    private fun sendOuter(type: Int, payload: ByteArray) {
        val message = Polo.outerMessage(type, payload)
        val out = output ?: error("Not connected")
        writeVarint(out, message.size.toLong())
        out.write(message)
        out.flush()
    }

    private fun readOuter(): Polo.Outer {
        val inp = input ?: error("Not connected")
        val len = readVarint(inp).toInt()
        val buffer = ByteArray(len)
        inp.readFully(buffer)
        return Polo.parseOuter(buffer)
    }

    private fun writeVarint(out: DataOutputStream, value: Long) {
        var v = value
        while (true) {
            if ((v and 0x7F.inv().toLong()) == 0L) {
                out.write(v.toInt())
                return
            } else {
                out.write(((v and 0x7F) or 0x80).toInt())
                v = v ushr 7
            }
        }
    }

    private fun readVarint(inp: DataInputStream): Long {
        var result = 0L
        var shift = 0
        while (true) {
            val b = inp.readUnsignedByte()
            result = result or ((b and 0x7F).toLong() shl shift)
            if (b and 0x80 == 0) break
            shift += 7
        }
        return result
    }
}
