package com.remotecontrol.tvhid.net

import android.os.Build
import com.remotecontrol.tvhid.proto.RemoteProto
import java.io.DataInputStream
import java.io.DataOutputStream
import javax.net.ssl.SSLSocket
import kotlin.concurrent.thread

/**
 * Persistent connection to the TV's remote-control service (port 6466).
 * Uses the same client certificate that was used during pairing - the TV
 * recognizes it and skips the pairing flow entirely.
 */
class RemoteSession(
    private val host: String,
    private val port: Int,
    private val identity: ClientIdentity
) {
    interface Listener {
        fun onConnected()
        fun onDisconnected(reason: String)
    }

    @Volatile private var running = false
    private var socket: SSLSocket? = null
    private var output: DataOutputStream? = null
    private var listener: Listener? = null

    fun connect(listener: Listener) {
        this.listener = listener
        running = true
        thread(name = "remote-session") {
            try {
                runSession()
            } catch (e: Exception) {
                listener.onDisconnected(e.message ?: e.toString())
            }
        }
    }

    private fun runSession() {
        val trustManager = TrustAllTrustManager()
        val context = TlsSupport.buildContext(identity, trustManager)
        val sock = context.socketFactory.createSocket(host, port) as SSLSocket
        sock.startHandshake()
        socket = sock
        val input = DataInputStream(sock.inputStream)
        val out = DataOutputStream(sock.outputStream)
        output = out

        out.write(
            RemoteProto.configure(
                model = Build.MODEL ?: "Phone",
                vendor = Build.MANUFACTURER ?: "Android",
                packageName = "com.remotecontrol.tvhid",
                appVersion = "1.0"
            )
        )
        out.flush()
        listener?.onConnected()

        while (running) {
            val len = readVarint(input).toInt()
            if (len <= 0) continue
            val buffer = ByteArray(len)
            input.readFully(buffer)
            val incoming = RemoteProto.parse(buffer)
            incoming.pingRequestVal1?.let { val1 ->
                out.write(RemoteProto.pingResponse(val1))
                out.flush()
            }
        }
    }

    fun sendKey(keyCode: Int) {
        val out = output ?: return
        thread(name = "send-key") {
            try {
                synchronized(out) {
                    out.write(RemoteProto.keyPress(keyCode))
                    out.flush()
                }
            } catch (_: Exception) {
                // Dropped key press is non-fatal; the read loop will notice
                // the disconnect and report it via the listener.
            }
        }
    }

    fun isConnected(): Boolean = running && socket?.isConnected == true

    fun disconnect() {
        running = false
        try { socket?.close() } catch (_: Exception) {}
    }

    private fun readVarint(inp: DataInputStream): Long {
        var result = 0L
        var shift = 0
        while (true) {
            val b = inp.readUnsignedByte()
            result = result or ((b and 0x7F).toLong() shl shift)
            if (b and 0x80 == 0) break
            shift += 7
        }
        return result
    }
}
