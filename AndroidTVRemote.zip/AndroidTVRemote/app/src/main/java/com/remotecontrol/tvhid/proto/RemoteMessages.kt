package com.remotecontrol.tvhid.proto

/**
 * Builders/parsers for the live remote-control protocol (TLS, port 6466).
 * Schema source: tronikos/androidtvremote2 remotemessage.proto (field numbers
 * copied verbatim from that file, which itself documents being derived from
 * louis49/androidtv-remote and the AOSP key code list).
 */
object RemoteProto {

    // RemoteMessage top-level field numbers (oneof-like; only set one per message)
    private const val F_REMOTE_CONFIGURE = 1
    private const val F_REMOTE_SET_ACTIVE = 2
    private const val F_PING_REQUEST = 8
    private const val F_PING_RESPONSE = 9
    private const val F_KEY_INJECT = 10

    // RemoteDirection
    const val DIR_SHORT = 3

    // A practical subset of RemoteKeyCode (full list has 300+ entries; these
    // cover every button this app exposes).
    object Key {
        const val HOME = 3
        const val BACK = 4
        const val DPAD_UP = 19
        const val DPAD_DOWN = 20
        const val DPAD_LEFT = 21
        const val DPAD_RIGHT = 22
        const val DPAD_CENTER = 23
        const val VOLUME_UP = 24
        const val VOLUME_DOWN = 25
        const val POWER = 26
        const val ENTER = 66
        const val MENU = 82
        const val MEDIA_PLAY_PAUSE = 85
        const val MEDIA_NEXT = 87
        const val MEDIA_PREVIOUS = 88
        const val MUTE = 91 // mic mute; most TVs route this to speaker mute too
        const val VOLUME_MUTE = 164 // dedicated speaker-mute toggle
    }

    /** First message sent on the 6466 connection: who we are. */
    fun configure(model: String, vendor: String, packageName: String, appVersion: String): ByteArray {
        val deviceInfo = ProtoWriter().apply {
            stringField(1, model)
            stringField(2, vendor)
            stringField(5, packageName)
            stringField(6, appVersion)
        }.toByteArray()

        val configure = ProtoWriter().apply {
            varintField(1, 622) // code1 - observed-convention value used by existing clients
            messageField(2, deviceInfo)
        }.toByteArray()

        val outer = ProtoWriter()
        outer.messageField(F_REMOTE_CONFIGURE, configure)
        return lengthPrefixed(outer.toByteArray())
    }

    fun setActive(active: Int = 1): ByteArray {
        val setActive = ProtoWriter().apply { varintField(1, active) }.toByteArray()
        val outer = ProtoWriter()
        outer.messageField(F_REMOTE_SET_ACTIVE, setActive)
        return lengthPrefixed(outer.toByteArray())
    }

    fun pingResponse(val1: Long): ByteArray {
        val resp = ProtoWriter().apply { varintField(1, val1) }.toByteArray()
        val outer = ProtoWriter()
        outer.messageField(F_PING_RESPONSE, resp)
        return lengthPrefixed(outer.toByteArray())
    }

    /** A single short key press (down+up are implicit as one SHORT direction event). */
    fun keyPress(keyCode: Int): ByteArray {
        val inject = ProtoWriter().apply {
            varintField(1, keyCode)
            varintField(2, DIR_SHORT)
        }.toByteArray()

        val outer = ProtoWriter()
        outer.messageField(F_KEY_INJECT, inject)
        return lengthPrefixed(outer.toByteArray())
    }

    /** Every outgoing RemoteMessage on this channel is prefixed with a varint length. */
    private fun lengthPrefixed(message: ByteArray): ByteArray {
        return varintBytes(message.size.toLong()) + message
    }

    private fun varintBytes(value: Long): ByteArray {
        val bytes = mutableListOf<Byte>()
        var v = value
        while (true) {
            if ((v and 0x7F.inv().toLong()) == 0L) {
                bytes.add(v.toByte())
                return bytes.toByteArray()
            } else {
                bytes.add(((v and 0x7F) or 0x80).toByte())
                v = v ushr 7
            }
        }
    }

    data class Incoming(
        val pingRequestVal1: Long?,
        val hasSetActive: Boolean,
        val hasConfigure: Boolean
    )

    /** Parses one (already length-delimited-stripped) RemoteMessage payload. */
    fun parse(data: ByteArray): Incoming {
        val f = ProtoReader.parse(data)
        val ping = f.message(F_PING_REQUEST)
        return Incoming(
            pingRequestVal1 = ping?.int(1),
            hasSetActive = f.containsKey(F_REMOTE_SET_ACTIVE),
            hasConfigure = f.containsKey(F_REMOTE_CONFIGURE)
        )
    }
}
