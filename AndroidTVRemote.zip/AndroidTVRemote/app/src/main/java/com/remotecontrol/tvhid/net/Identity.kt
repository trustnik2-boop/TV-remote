package com.remotecontrol.tvhid.net

import android.content.Context
import android.util.Base64
import org.bouncycastle.asn1.x500.X500Name
import org.bouncycastle.cert.X509v3CertificateBuilder
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder
import java.math.BigInteger
import java.security.KeyFactory
import java.security.KeyPairGenerator
import java.security.PrivateKey
import java.security.PublicKey
import java.security.SecureRandom
import java.security.Security
import java.security.cert.CertificateFactory
import java.security.cert.X509Certificate
import java.security.spec.PKCS8EncodedKeySpec
import java.util.Date

/**
 * Generates (once) and persists a self-signed RSA client identity used for
 * mutual TLS with the TV. The TV remembers this certificate after a
 * successful pairing, so we must keep reusing the same one — regenerating it
 * would force the user to re-pair.
 */
class ClientIdentity private constructor(
    val certificate: X509Certificate,
    val privateKey: PrivateKey
) {
    val publicKey: PublicKey get() = certificate.publicKey

    companion object {
        private const val PREFS = "tv_remote_identity"
        private const val KEY_CERT = "cert_b64"
        private const val KEY_PRIVATE = "key_b64"

        fun loadOrCreate(context: Context): ClientIdentity {
            Security.addProvider(org.bouncycastle.jce.provider.BouncyCastleProvider())
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val existingCert = prefs.getString(KEY_CERT, null)
            val existingKey = prefs.getString(KEY_PRIVATE, null)

            if (existingCert != null && existingKey != null) {
                val certBytes = Base64.decode(existingCert, Base64.DEFAULT)
                val keyBytes = Base64.decode(existingKey, Base64.DEFAULT)
                val cert = CertificateFactory.getInstance("X.509")
                    .generateCertificate(certBytes.inputStream()) as X509Certificate
                val key = KeyFactory.getInstance("RSA")
                    .generatePrivate(PKCS8EncodedKeySpec(keyBytes))
                return ClientIdentity(cert, key)
            }

            val identity = generate()
            prefs.edit()
                .putString(KEY_CERT, Base64.encodeToString(identity.certificate.encoded, Base64.DEFAULT))
                .putString(KEY_PRIVATE, Base64.encodeToString(identity.privateKey.encoded, Base64.DEFAULT))
                .apply()
            return identity
        }

        private fun generate(): ClientIdentity {
            val keyGen = KeyPairGenerator.getInstance("RSA")
            keyGen.initialize(2048, SecureRandom())
            val keyPair = keyGen.generateKeyPair()

            val now = Date()
            val notAfter = Date(now.time + 1000L * 60 * 60 * 24 * 365 * 20) // 20 years
            val serial = BigInteger(64, SecureRandom())
            val subject = X500Name("CN=TvRemoteClient")

            val builder: X509v3CertificateBuilder = JcaX509v3CertificateBuilder(
                subject, serial, now, notAfter, subject, keyPair.public
            )
            val signer = JcaContentSignerBuilder("SHA256WithRSA").build(keyPair.private)
            val holder = builder.build(signer)
            val cert = JcaX509CertificateConverter().getCertificate(holder)

            return ClientIdentity(cert, keyPair.private)
        }
    }
}
