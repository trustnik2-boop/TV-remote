package com.remotecontrol.tvhid

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs

/**
 * The Android TV Remote v2 protocol has no "move pointer by dx/dy" message —
 * only discrete key presses. So this touchpad translates gestures into
 * bursts of D-pad key presses, the same trick most Wi-Fi-based universal
 * remote apps use to approximate a trackpad:
 *   - 1-finger swipe   -> repeated DPAD_UP/DOWN/LEFT/RIGHT in that direction
 *   - 1-finger tap     -> DPAD_CENTER (OK)
 *   - 2-finger tap     -> BACK
 */
class TouchpadView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class Direction { UP, DOWN, LEFT, RIGHT }

    interface Listener {
        fun onSwipe(direction: Direction)
        fun onTap()
        fun onTwoFingerTap()
    }

    var listener: Listener? = null

    /** Pixels of drag before we fire one more step in that direction. */
    var stepSizePx: Float = 60f

    private var lastX = 0f
    private var lastY = 0f
    private var accumX = 0f
    private var accumY = 0f
    private var lastPointerCount = 0
    private var moved = false
    private var downTime = 0L
    private val tapTimeoutMs = 220L

    private val bgPaint = Paint().apply {
        color = Color.parseColor("#262633")
        style = Paint.Style.FILL
    }
    private val borderPaint = Paint().apply {
        color = Color.parseColor("#26FFFFFF")
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), 28f, 28f, bgPaint)
        canvas.drawRoundRect(2f, 2f, width - 2f, height - 2f, 28f, 28f, borderPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x
                lastY = event.y
                accumX = 0f
                accumY = 0f
                lastPointerCount = 1
                moved = false
                downTime = System.currentTimeMillis()
            }

            MotionEvent.ACTION_POINTER_DOWN -> {
                lastPointerCount = event.pointerCount
                lastX = centroidX(event)
                lastY = centroidY(event)
                moved = false
            }

            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount == 1) {
                    val cx = event.x
                    val cy = event.y
                    val dx = cx - lastX
                    val dy = cy - lastY
                    accumX += dx
                    accumY += dy
                    lastX = cx
                    lastY = cy

                    if (abs(accumX) > abs(accumY)) {
                        while (abs(accumX) >= stepSizePx) {
                            listener?.onSwipe(if (accumX > 0) Direction.RIGHT else Direction.LEFT)
                            accumX -= stepSizePx * Math.signum(accumX)
                            moved = true
                        }
                    } else {
                        while (abs(accumY) >= stepSizePx) {
                            listener?.onSwipe(if (accumY > 0) Direction.DOWN else Direction.UP)
                            accumY -= stepSizePx * Math.signum(accumY)
                            moved = true
                        }
                    }
                }
            }

            MotionEvent.ACTION_UP -> {
                val elapsed = System.currentTimeMillis() - downTime
                if (!moved && elapsed < tapTimeoutMs) {
                    if (lastPointerCount >= 2) listener?.onTwoFingerTap() else listener?.onTap()
                }
                lastPointerCount = 0
            }
        }
        return true
    }

    private fun centroidX(event: MotionEvent): Float {
        var sum = 0f
        for (i in 0 until event.pointerCount) sum += event.getX(i)
        return sum / event.pointerCount
    }

    private fun centroidY(event: MotionEvent): Float {
        var sum = 0f
        for (i in 0 until event.pointerCount) sum += event.getY(i)
        return sum / event.pointerCount
    }
}
