package com.remotecontrol.tvhid

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * A laptop-style touchpad:
 *  - 1 finger drag  -> relative mouse move
 *  - 1 finger tap   -> left click
 *  - 2 finger tap   -> right click / "back"
 *  - 2 finger vertical drag -> scroll wheel
 *
 * Movement is reported as small relative deltas via [Listener], scaled by
 * [sensitivity], so the on-screen pad only needs a fraction of the TV
 * screen's size to move the cursor all the way across it (same idea as a
 * laptop trackpad).
 */
class TouchpadView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    interface Listener {
        fun onMove(dx: Int, dy: Int)
        fun onLeftClick()
        fun onRightClick()
        fun onScroll(amount: Int)
    }

    var listener: Listener? = null
    var sensitivity: Float = 1.6f

    private var lastX = 0f
    private var lastY = 0f
    private var lastPointerCount = 0
    private var moved = false
    private var downTime = 0L
    private val tapTimeoutMs = 200L
    private val tapSlopPx = 12f

    private val bgPaint = Paint().apply {
        color = Color.parseColor("#1E1E1E")
        style = Paint.Style.FILL
    }
    private val borderPaint = Paint().apply {
        color = Color.parseColor("#3A3A3A")
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), 24f, 24f, bgPaint)
        canvas.drawRoundRect(2f, 2f, width - 2f, height - 2f, 24f, 24f, borderPaint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = event.x
                lastY = event.y
                lastPointerCount = 1
                moved = false
                downTime = System.currentTimeMillis()
            }

            MotionEvent.ACTION_POINTER_DOWN -> {
                lastPointerCount = event.pointerCount
                lastX = centroidX(event)
                lastY = centroidY(event)
                moved = false
            }

            MotionEvent.ACTION_MOVE -> {
                val cx = centroidX(event)
                val cy = centroidY(event)
                val dx = cx - lastX
                val dy = cy - lastY

                if (abs(dx) > 1f || abs(dy) > 1f) {
                    if (event.pointerCount >= 2) {
                        // Two-finger drag -> scroll (vertical only, like a trackpad)
                        listener?.onScroll((-dy / 8f).roundToInt())
                    } else {
                        listener?.onMove(
                            (dx * sensitivity).roundToInt(),
                            (dy * sensitivity).roundToInt()
                        )
                    }
                    moved = true
                }
                lastX = cx
                lastY = cy
            }

            MotionEvent.ACTION_POINTER_UP -> {
                // Falling back to one finger; resync the anchor point so the
                // remaining finger doesn't cause a jump.
                val upIndex = event.actionIndex
                val remainingPointers = event.pointerCount - 1
                if (remainingPointers >= 1) {
                    var sx = 0f; var sy = 0f; var n = 0
                    for (i in 0 until event.pointerCount) {
                        if (i == upIndex) continue
                        sx += event.getX(i); sy += event.getY(i); n++
                    }
                    if (n > 0) { lastX = sx / n; lastY = sy / n }
                }
            }

            MotionEvent.ACTION_UP -> {
                val elapsed = System.currentTimeMillis() - downTime
                if (!moved && elapsed < tapTimeoutMs) {
                    if (lastPointerCount >= 2) listener?.onRightClick() else listener?.onLeftClick()
                }
                lastPointerCount = 0
            }
        }
        return true
    }

    private fun centroidX(event: MotionEvent): Float {
        var sum = 0f
        for (i in 0 until event.pointerCount) sum += event.getX(i)
        return sum / event.pointerCount
    }

    private fun centroidY(event: MotionEvent): Float {
        var sum = 0f
        for (i in 0 until event.pointerCount) sum += event.getY(i)
        return sum / event.pointerCount
    }
}
