package com.remotecontrol.tvhid.proto

import java.io.ByteArrayOutputStream

/**
 * Hand-rolled protobuf (proto3) wire format encoder/decoder.
 *
 * We avoid the protoc toolchain entirely and implement just the two wire
 * types this protocol actually uses:
 *   0 = varint   (bool, int32/64, uint32/64, enum)
 *   2 = length-delimited (string, bytes, embedded message)
 *
 * This keeps the Gradle build dependency-free and the wire format fully
 * auditable against the real .proto schemas (polo.proto / remotemessage.proto).
 */
class ProtoWriter {
    private val out = ByteArrayOutputStream()

    private fun writeVarint(value: Long) {
        var v = value
        while (true) {
            if ((v and 0x7F.inv().toLong()) == 0L) {
                out.write(v.toInt())
                return
            } else {
                out.write(((v and 0x7F) or 0x80).toInt())
                v = v ushr 7
            }
        }
    }

    private fun tag(fieldNumber: Int, wireType: Int) {
        writeVarint(((fieldNumber.toLong() shl 3) or wireType.toLong()))
    }

    fun varintField(fieldNumber: Int, value: Long) {
        tag(fieldNumber, 0)
        writeVarint(value)
    }

    fun varintField(fieldNumber: Int, value: Int) = varintField(fieldNumber, value.toLong())
    fun boolField(fieldNumber: Int, value: Boolean) = varintField(fieldNumber, if (value) 1L else 0L)

    fun bytesField(fieldNumber: Int, value: ByteArray) {
        tag(fieldNumber, 2)
        writeVarint(value.size.toLong())
        out.write(value)
    }

    fun stringField(fieldNumber: Int, value: String) = bytesField(fieldNumber, value.toByteArray(Charsets.UTF_8))

    fun messageField(fieldNumber: Int, message: ByteArray) = bytesField(fieldNumber, message)

    fun toByteArray(): ByteArray = out.toByteArray()
}

/** A single decoded field: either a varint value or a length-delimited blob. */
sealed class Field {
    data class Varint(val value: Long) : Field()
    data class Bytes(val value: ByteArray) : Field()
}

/**
 * Parses a flat proto message into field-number -> values (repeated fields
 * keep every occurrence, last one usually "wins" per proto3 semantics for
 * singular fields).
 */
object ProtoReader {
    fun parse(data: ByteArray): Map<Int, MutableList<Field>> {
        val result = mutableMapOf<Int, MutableList<Field>>()
        var pos = 0
        while (pos < data.size) {
            val (tagVal, afterTag) = readVarint(data, pos)
            pos = afterTag
            val fieldNumber = (tagVal shr 3).toInt()
            val wireType = (tagVal and 0x7).toInt()
            when (wireType) {
                0 -> {
                    val (v, next) = readVarint(data, pos)
                    pos = next
                    result.getOrPut(fieldNumber) { mutableListOf() }.add(Field.Varint(v))
                }
                2 -> {
                    val (len, next) = readVarint(data, pos)
                    pos = next
                    val slice = data.copyOfRange(pos, pos + len.toInt())
                    pos += len.toInt()
                    result.getOrPut(fieldNumber) { mutableListOf() }.add(Field.Bytes(slice))
                }
                else -> error("Unsupported wire type $wireType at field $fieldNumber")
            }
        }
        return result
    }

    private fun readVarint(data: ByteArray, start: Int): Pair<Long, Int> {
        var result = 0L
        var shift = 0
        var pos = start
        while (true) {
            val b = data[pos].toInt() and 0xFF
            result = result or ((b and 0x7F).toLong() shl shift)
            pos++
            if (b and 0x80 == 0) break
            shift += 7
        }
        return Pair(result, pos)
    }
}

fun Map<Int, MutableList<Field>>.string(field: Int): String? =
    (this[field]?.lastOrNull() as? Field.Bytes)?.value?.toString(Charsets.UTF_8)

fun Map<Int, MutableList<Field>>.bytes(field: Int): ByteArray? =
    (this[field]?.lastOrNull() as? Field.Bytes)?.value

fun Map<Int, MutableList<Field>>.int(field: Int): Long? =
    (this[field]?.lastOrNull() as? Field.Varint)?.value

fun Map<Int, MutableList<Field>>.message(field: Int): Map<Int, MutableList<Field>>? =
    bytes(field)?.let { ProtoReader.parse(it) }
