package com.remotecontrol.tvhid

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothProfile
import android.os.Build
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var hidManager: HidRemoteManager
    private lateinit var statusText: TextView
    private lateinit var deviceSpinner: Spinner
    private var bondedDevices: List<BluetoothDevice> = emptyList()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) {
            initBluetooth()
        } else {
            Toast.makeText(this, "Bluetooth permissions are required", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        deviceSpinner = findViewById(R.id.deviceSpinner)
        hidManager = HidRemoteManager(applicationContext)

        hidManager.listener = object : HidRemoteManager.Listener {
            override fun onAppRegistered(success: Boolean) {
                runOnUiThread {
                    statusText.text = if (success) "Ready — pick a device to connect"
                    else "Failed to register HID profile. Check your network/BT settings."
                }
            }

            override fun onConnectionStateChanged(device: BluetoothDevice?, state: Int) {
                runOnUiThread {
                    statusText.text = when (state) {
                        BluetoothProfile.STATE_CONNECTED -> "Connected to ${safeName(device)}"
                        BluetoothProfile.STATE_CONNECTING -> "Connecting to ${safeName(device)}…"
                        BluetoothProfile.STATE_DISCONNECTED -> "Disconnected"
                        else -> "State: $state"
                    }
                }
            }
        }

        setupModeToggle()
        setupRemoteButtons()
        setupTouchpad()
        setupConnectButton()

        requestNeededPermissions()
    }

    private fun safeName(device: BluetoothDevice?): String {
        return try { device?.name ?: device?.address ?: "device" } catch (_: SecurityException) { "device" }
    }

    // ---- Permissions -----------------------------------------------------

    private fun requestNeededPermissions() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 31) {
            needed += Manifest.permission.BLUETOOTH_CONNECT
            needed += Manifest.permission.BLUETOOTH_SCAN
        } else {
            needed += Manifest.permission.ACCESS_FINE_LOCATION
        }
        val toRequest = needed.filter {
            androidx.core.content.ContextCompat.checkSelfPermission(this, it) !=
                android.content.pm.PackageManager.PERMISSION_GRANTED
        }
        if (toRequest.isEmpty()) initBluetooth() else permissionLauncher.launch(toRequest.toTypedArray())
    }

    private fun initBluetooth() {
        hidManager.start()
        loadBondedDevices()
    }

    @SuppressLint("MissingPermission")
    private fun loadBondedDevices() {
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) {
            statusText.text = "This device has no Bluetooth adapter"
            return
        }
        val devices = try { adapter.bondedDevices.toList() } catch (_: SecurityException) { emptyList() }
        bondedDevices = devices
        val names = devices.map { safeName(it) }.ifEmpty { listOf("No paired devices found") }
        deviceSpinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
    }

    private fun setupConnectButton() {
        findViewById<Button>(R.id.btnConnect).setOnClickListener {
            val index = deviceSpinner.selectedItemPosition
            val device = bondedDevices.getOrNull(index)
            if (device == null) {
                Toast.makeText(
                    this,
                    "Pair with your TV first in Android Bluetooth settings, then reopen this app",
                    Toast.LENGTH_LONG
                ).show()
            } else {
                hidManager.connect(device)
            }
        }
    }

    // ---- Mode toggle -------------------------------------------------------

    private fun setupModeToggle() {
        val remotePanel = findViewById<android.widget.LinearLayout>(R.id.remotePanel)
        val touchpadPanel = findViewById<android.widget.LinearLayout>(R.id.touchpadPanel)

        findViewById<Button>(R.id.btnModeRemote).setOnClickListener {
            remotePanel.visibility = android.view.View.VISIBLE
            touchpadPanel.visibility = android.view.View.GONE
        }
        findViewById<Button>(R.id.btnModeTouchpad).setOnClickListener {
            remotePanel.visibility = android.view.View.GONE
            touchpadPanel.visibility = android.view.View.VISIBLE
        }
    }

    // ---- D-pad / media buttons --------------------------------------------

    private fun setupRemoteButtons() {
        findViewById<Button>(R.id.btnUp).setOnClickListener { hidManager.sendKey(KeyCode.UP_ARROW) }
        findViewById<Button>(R.id.btnDown).setOnClickListener { hidManager.sendKey(KeyCode.DOWN_ARROW) }
        findViewById<Button>(R.id.btnLeft).setOnClickListener { hidManager.sendKey(KeyCode.LEFT_ARROW) }
        findViewById<Button>(R.id.btnRight).setOnClickListener { hidManager.sendKey(KeyCode.RIGHT_ARROW) }
        findViewById<Button>(R.id.btnOk).setOnClickListener { hidManager.sendKey(KeyCode.ENTER) }
        findViewById<Button>(R.id.btnBack).setOnClickListener { hidManager.sendKey(KeyCode.ESCAPE) }
        findViewById<Button>(R.id.btnHome).setOnClickListener { hidManager.sendConsumer(ConsumerBit.AC_HOME) }
        findViewById<Button>(R.id.btnMenu).setOnClickListener { hidManager.sendConsumer(ConsumerBit.MENU) }

        findViewById<Button>(R.id.btnVolUp).setOnClickListener { hidManager.sendConsumer(ConsumerBit.VOLUME_UP) }
        findViewById<Button>(R.id.btnVolDown).setOnClickListener { hidManager.sendConsumer(ConsumerBit.VOLUME_DOWN) }
        findViewById<Button>(R.id.btnMute).setOnClickListener { hidManager.sendConsumer(ConsumerBit.MUTE) }
        findViewById<Button>(R.id.btnPlayPause).setOnClickListener { hidManager.sendConsumer(ConsumerBit.PLAY_PAUSE) }
        findViewById<Button>(R.id.btnNext).setOnClickListener { hidManager.sendConsumer(ConsumerBit.NEXT_TRACK) }
        findViewById<Button>(R.id.btnPrev).setOnClickListener { hidManager.sendConsumer(ConsumerBit.PREV_TRACK) }
    }

    // ---- Touchpad ------------------------------------------------------

    private fun setupTouchpad() {
        val touchpad = findViewById<TouchpadView>(R.id.touchpad)
        touchpad.listener = object : TouchpadView.Listener {
            override fun onMove(dx: Int, dy: Int) = hidManager.sendMouseMove(dx, dy)
            override fun onLeftClick() = hidManager.sendMouseClick(MouseButton.LEFT)
            override fun onRightClick() = hidManager.sendMouseClick(MouseButton.RIGHT)
            override fun onScroll(amount: Int) = hidManager.sendMouseMove(0, 0, amount)
        }

        findViewById<Button>(R.id.btnLeftClick).setOnClickListener {
            hidManager.sendMouseClick(MouseButton.LEFT)
        }
        findViewById<Button>(R.id.btnRightClick).setOnClickListener {
            hidManager.sendMouseClick(MouseButton.RIGHT)
        }
    }

    override fun onDestroy() {
        hidManager.stop()
        super.onDestroy()
    }
}
