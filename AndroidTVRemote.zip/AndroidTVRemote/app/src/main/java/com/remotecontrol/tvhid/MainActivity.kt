package com.remotecontrol.tvhid

import android.Manifest
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.remotecontrol.tvhid.net.ClientIdentity
import com.remotecontrol.tvhid.net.DiscoveredTv
import com.remotecontrol.tvhid.net.PairingClient
import com.remotecontrol.tvhid.net.RemoteSession
import com.remotecontrol.tvhid.net.TvDiscovery
import com.remotecontrol.tvhid.proto.RemoteProto

class MainActivity : AppCompatActivity() {

    private lateinit var identity: ClientIdentity
    private lateinit var discovery: TvDiscovery
    private lateinit var statusText: TextView
    private lateinit var tvNameView: TextView
    private lateinit var deviceSpinner: Spinner

    private var foundTvs = mutableListOf<DiscoveredTv>()
    private var session: RemoteSession? = null
    private var pairingClient: PairingClient? = null

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { startDiscovery() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        tvNameView = findViewById(R.id.tvName)
        deviceSpinner = findViewById(R.id.deviceSpinner)

        identity = ClientIdentity.loadOrCreate(applicationContext)
        discovery = TvDiscovery(applicationContext)

        setupModeToggle()
        setupRemoteButtons()
        setupTouchpad()
        setupConnectButton()

        requestNeededPermissions()
    }

    private fun requestNeededPermissions() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= 33) needed += Manifest.permission.NEARBY_WIFI_DEVICES
        val toRequest = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (toRequest.isEmpty()) startDiscovery() else permissionLauncher.launch(toRequest.toTypedArray())
    }

    private fun startDiscovery() {
        statusText.text = "Searching for TVs on your Wi-Fi…"
        discovery.start(object : TvDiscovery.Listener {
            override fun onFound(tv: DiscoveredTv) {
                runOnUiThread {
                    if (foundTvs.none { it.host == tv.host }) {
                        foundTvs.add(tv)
                        deviceSpinner.adapter = ArrayAdapter(
                            this@MainActivity,
                            android.R.layout.simple_spinner_dropdown_item,
                            foundTvs.map { it.name }
                        )
                        statusText.text = "Found ${foundTvs.size} TV(s) — pick one and tap Connect"
                    }
                }
            }

            override fun onLost(name: String) {
                runOnUiThread {
                    foundTvs.removeAll { it.name == name }
                }
            }
        })
    }

    private fun setupConnectButton() {
        findViewById<Button>(R.id.btnConnect).setOnClickListener {
            val tv = foundTvs.getOrNull(deviceSpinner.selectedItemPosition)
            if (tv == null) {
                Toast.makeText(this, "No TV found yet — make sure it's on the same Wi-Fi", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            tvNameView.text = tv.name
            beginPairingOrConnect(tv)
        }
    }

    private fun beginPairingOrConnect(tv: DiscoveredTv) {
        statusText.text = "Connecting to ${tv.name}…"
        // Try the remote-control port directly first; the TV accepts it
        // immediately if this cert was already paired before.
        connectRemoteSession(tv)
    }

    private fun connectRemoteSession(tv: DiscoveredTv) {
        val s = RemoteSession(tv.host, 6466, identity)
        session = s
        s.connect(object : RemoteSession.Listener {
            override fun onConnected() {
                runOnUiThread { statusText.text = "Connected to ${tv.name}" }
            }

            override fun onDisconnected(reason: String) {
                runOnUiThread {
                    // Most likely cause of an immediate failure: not paired yet.
                    statusText.text = "Not paired yet — pairing with ${tv.name}…"
                    startPairing(tv)
                }
            }
        })
    }

    private fun startPairing(tv: DiscoveredTv) {
        val client = PairingClient(tv.host, 6467, identity)
        pairingClient = client
        client.begin(object : PairingClient.Listener {
            override fun onCodeNeeded() {
                runOnUiThread { showCodeEntryDialog(tv, client) }
            }

            override fun onCodeRejected() {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "Code didn't match — try again", Toast.LENGTH_SHORT).show()
                    showCodeEntryDialog(tv, client)
                }
            }

            override fun onPaired() {
                runOnUiThread {
                    statusText.text = "Paired! Connecting…"
                    connectRemoteSession(tv)
                }
            }

            override fun onFailed(message: String) {
                runOnUiThread { statusText.text = "Pairing failed: $message" }
            }
        })
    }

    private fun showCodeEntryDialog(tv: DiscoveredTv, client: PairingClient) {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT
            hint = "6-character code from the TV"
        }
        AlertDialog.Builder(this)
            .setTitle("Enter the code shown on ${tv.name}")
            .setView(input)
            .setPositiveButton("Pair") { _, _ ->
                statusText.text = "Verifying code…"
                client.submitCode(input.text.toString())
            }
            .setNegativeButton("Cancel") { _, _ -> client.close() }
            .setCancelable(false)
            .show()
    }

    // ---- Mode toggle -------------------------------------------------------

    private fun setupModeToggle() {
        val remotePanel = findViewById<LinearLayout>(R.id.remotePanel)
        val touchpadPanel = findViewById<LinearLayout>(R.id.touchpadPanel)
        val btnRemote = findViewById<Button>(R.id.btnModeRemote)
        val btnTouchpad = findViewById<Button>(R.id.btnModeTouchpad)

        btnRemote.setOnClickListener {
            remotePanel.visibility = android.view.View.VISIBLE
            touchpadPanel.visibility = android.view.View.GONE
            btnRemote.setBackgroundResource(R.drawable.segment_active)
            btnTouchpad.background = null
        }
        btnTouchpad.setOnClickListener {
            remotePanel.visibility = android.view.View.GONE
            touchpadPanel.visibility = android.view.View.VISIBLE
            btnTouchpad.setBackgroundResource(R.drawable.segment_active)
            btnRemote.background = null
        }
    }

    // ---- D-pad / media buttons --------------------------------------------

    private fun setupRemoteButtons() {
        findViewById<Button>(R.id.btnUp).setOnClickListener { sendKey(RemoteProto.Key.DPAD_UP) }
        findViewById<Button>(R.id.btnDown).setOnClickListener { sendKey(RemoteProto.Key.DPAD_DOWN) }
        findViewById<Button>(R.id.btnLeft).setOnClickListener { sendKey(RemoteProto.Key.DPAD_LEFT) }
        findViewById<Button>(R.id.btnRight).setOnClickListener { sendKey(RemoteProto.Key.DPAD_RIGHT) }
        findViewById<Button>(R.id.btnOk).setOnClickListener { sendKey(RemoteProto.Key.DPAD_CENTER) }
        findViewById<Button>(R.id.btnBack).setOnClickListener { sendKey(RemoteProto.Key.BACK) }
        findViewById<Button>(R.id.btnHome).setOnClickListener { sendKey(RemoteProto.Key.HOME) }
        findViewById<Button>(R.id.btnMenu).apply {
            // Many newer Android TVs ignore the classic MENU key; SETTINGS works on most.
            setOnClickListener { sendKey(RemoteProto.Key.SETTINGS) }
            setOnLongClickListener { sendKey(RemoteProto.Key.MENU); true }
        }

        findViewById<Button>(R.id.btnVolUp).setOnClickListener { sendKey(RemoteProto.Key.VOLUME_UP) }
        findViewById<Button>(R.id.btnVolDown).setOnClickListener { sendKey(RemoteProto.Key.VOLUME_DOWN) }
        findViewById<Button>(R.id.btnMute).setOnClickListener { sendKey(RemoteProto.Key.VOLUME_MUTE) }
        findViewById<Button>(R.id.btnPlayPause).setOnClickListener { sendKey(RemoteProto.Key.MEDIA_PLAY_PAUSE) }
        findViewById<Button>(R.id.btnNext).setOnClickListener { sendKey(RemoteProto.Key.MEDIA_NEXT) }
        findViewById<Button>(R.id.btnPrev).setOnClickListener { sendKey(RemoteProto.Key.MEDIA_PREVIOUS) }
    }

    // ---- Touchpad ------------------------------------------------------

    private fun setupTouchpad() {
        val touchpad = findViewById<TouchpadView>(R.id.touchpad)
        touchpad.listener = object : TouchpadView.Listener {
            override fun onSwipe(direction: TouchpadView.Direction) {
                val key = when (direction) {
                    TouchpadView.Direction.UP -> RemoteProto.Key.DPAD_UP
                    TouchpadView.Direction.DOWN -> RemoteProto.Key.DPAD_DOWN
                    TouchpadView.Direction.LEFT -> RemoteProto.Key.DPAD_LEFT
                    TouchpadView.Direction.RIGHT -> RemoteProto.Key.DPAD_RIGHT
                }
                sendKey(key)
            }
            override fun onTap() = sendKey(RemoteProto.Key.DPAD_CENTER)
            override fun onTwoFingerTap() = sendKey(RemoteProto.Key.BACK)
        }

        findViewById<Button>(R.id.btnLeftClick).setOnClickListener { sendKey(RemoteProto.Key.DPAD_CENTER) }
        findViewById<Button>(R.id.btnRightClick).setOnClickListener { sendKey(RemoteProto.Key.BACK) }
    }

    private fun sendKey(keyCode: Int) {
        val s = session
        if (s == null || !s.isConnected()) {
            Toast.makeText(this, "Not connected to a TV yet", Toast.LENGTH_SHORT).show()
            return
        }
        s.sendKey(keyCode)
    }

    override fun onDestroy() {
        discovery.stop()
        session?.disconnect()
        pairingClient?.close()
        super.onDestroy()
    }
}
