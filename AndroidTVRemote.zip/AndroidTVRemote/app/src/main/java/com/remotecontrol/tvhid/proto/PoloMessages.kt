package com.remotecontrol.tvhid.proto

/**
 * Builders/parsers for the "Polo" pairing protocol (TLS, port 6467).
 * Schema source: AOSP platform/external/google-tv-pairing-protocol proto/polo.proto
 * (package polo.wire.protobuf). Field numbers below match that file exactly.
 */
object Polo {
    // OuterMessage.MessageType
    const val TYPE_PAIRING_REQUEST = 10
    const val TYPE_PAIRING_REQUEST_ACK = 11
    const val TYPE_OPTIONS = 20
    const val TYPE_CONFIGURATION = 30
    const val TYPE_CONFIGURATION_ACK = 31
    const val TYPE_SECRET = 40
    const val TYPE_SECRET_ACK = 41

    // OuterMessage.Status
    const val STATUS_OK = 200
    const val STATUS_ERROR = 400
    const val STATUS_BAD_CONFIGURATION = 401
    const val STATUS_BAD_SECRET = 402

    // Options.Encoding.EncodingType
    const val ENCODING_HEXADECIMAL = 3

    // Options.RoleType
    const val ROLE_INPUT = 1
    const val ROLE_OUTPUT = 2

    data class Outer(
        val protocolVersion: Int,
        val status: Int,
        val type: Int?,
        val payload: ByteArray?
    )

    /** Builds a complete OuterMessage wrapping [payload] as [type]. */
    fun outerMessage(type: Int, payload: ByteArray, protocolVersion: Int = 2): ByteArray {
        val w = ProtoWriter()
        w.varintField(1, protocolVersion)
        w.varintField(2, STATUS_OK)
        w.varintField(3, type)
        w.bytesField(4, payload)
        return w.toByteArray()
    }

    fun parseOuter(data: ByteArray): Outer {
        val f = ProtoReader.parse(data)
        return Outer(
            protocolVersion = (f.int(1) ?: 1L).toInt(),
            status = (f.int(2) ?: 0L).toInt(),
            type = f.int(3)?.toInt(),
            payload = f.bytes(4)
        )
    }

    fun pairingRequest(serviceName: String, clientName: String): ByteArray {
        val w = ProtoWriter()
        w.stringField(1, serviceName)
        w.stringField(2, clientName)
        return w.toByteArray()
    }

    /** Options message this client sends: "I can display/accept a 6-digit hex code, I want the INPUT role." */
    fun options(): ByteArray {
        val encoding = ProtoWriter().apply {
            varintField(1, ENCODING_HEXADECIMAL)
            varintField(2, 6) // symbol_length
        }.toByteArray()

        val w = ProtoWriter()
        w.messageField(1, encoding) // input_encodings (repeated, one entry is enough)
        w.varintField(3, ROLE_INPUT) // preferred_role
        return w.toByteArray()
    }

    fun configuration(): ByteArray {
        val encoding = ProtoWriter().apply {
            varintField(1, ENCODING_HEXADECIMAL)
            varintField(2, 6)
        }.toByteArray()

        val w = ProtoWriter()
        w.messageField(1, encoding) // encoding
        w.varintField(2, ROLE_INPUT) // client_role
        return w.toByteArray()
    }

    fun secret(secretBytes: ByteArray): ByteArray {
        val w = ProtoWriter()
        w.bytesField(1, secretBytes)
        return w.toByteArray()
    }
}
