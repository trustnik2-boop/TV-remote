package com.remotecontrol.tvhid.proto

/**
 * Pairing protocol (TLS, port 6467) - v2 "PairingMessage" layout used by
 * modern Android TV / Google TV. Each payload is an embedded message stored
 * directly at a field number equal to its message type (10, 11, 20, ...),
 * rather than a separate type + bytes payload pair.
 */
object Polo {
    const val TYPE_PAIRING_REQUEST = 10
    const val TYPE_PAIRING_REQUEST_ACK = 11
    const val TYPE_OPTIONS = 20
    const val TYPE_CONFIGURATION = 30
    const val TYPE_CONFIGURATION_ACK = 31
    const val TYPE_SECRET = 40
    const val TYPE_SECRET_ACK = 41

    const val STATUS_OK = 200

    const val ENCODING_HEXADECIMAL = 3
    const val ROLE_INPUT = 1
    const val SYMBOL_LENGTH = 4

    data class Outer(
        val protocolVersion: Int,
        val status: Int,
        val type: Int?,
        val payload: ByteArray?,
        val debug: String
    )

    /** Wraps [payload] as the embedded field number [type]. */
    fun outerMessage(type: Int, payload: ByteArray, protocolVersion: Int = 2): ByteArray {
        val w = ProtoWriter()
        w.varintField(1, protocolVersion)
        w.varintField(2, STATUS_OK)
        w.messageField(type, payload)
        return w.toByteArray()
    }

    private val KNOWN_TYPES = listOf(10, 11, 20, 30, 31, 40, 41)

    fun parseOuter(data: ByteArray): Outer {
        val f = ProtoReader.parse(data)
        val type = KNOWN_TYPES.firstOrNull { f.containsKey(it) }
        val hex = data.joinToString("") { "%02x".format(it) }
        return Outer(
            protocolVersion = (f.int(1) ?: 1L).toInt(),
            status = (f.int(2) ?: 0L).toInt(),
            type = type,
            payload = type?.let { f.bytes(it) },
            debug = "status=${f.int(2)} fields=${f.keys} raw=$hex"
        )
    }

    fun pairingRequest(serviceName: String, clientName: String): ByteArray {
        val w = ProtoWriter()
        w.stringField(1, serviceName)
        w.stringField(2, clientName)
        return w.toByteArray()
    }

    private fun encoding(): ByteArray = ProtoWriter().apply {
        varintField(1, ENCODING_HEXADECIMAL)
        varintField(2, SYMBOL_LENGTH)
    }.toByteArray()

    fun options(): ByteArray {
        val w = ProtoWriter()
        w.messageField(1, encoding())   // input_encodings
        w.varintField(3, ROLE_INPUT)    // preferred_role
        return w.toByteArray()
    }

    /** Picks the encoding the TV advertised (its output encoding), falling back to ours. */
    fun chooseEncoding(serverOptionsPayload: ByteArray?): ByteArray {
        if (serverOptionsPayload == null) return encoding()
        val f = ProtoReader.parse(serverOptionsPayload)
        val outputs = f[2]?.filterIsInstance<Field.Bytes>()
        val inputs = f[1]?.filterIsInstance<Field.Bytes>()
        return outputs?.firstOrNull()?.value ?: inputs?.firstOrNull()?.value ?: encoding()
    }

    fun configuration(encodingBytes: ByteArray = encoding()): ByteArray {
        val w = ProtoWriter()
        w.messageField(1, encodingBytes) // encoding
        w.varintField(2, ROLE_INPUT)     // client_role
        return w.toByteArray()
    }

    fun secret(secretBytes: ByteArray): ByteArray {
        val w = ProtoWriter()
        w.bytesField(1, secretBytes)
        return w.toByteArray()
    }
}
