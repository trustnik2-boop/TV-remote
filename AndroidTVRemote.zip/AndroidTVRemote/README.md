# TV Remote over Wi-Fi (Android TV Remote Protocol v2)

Controls an Android TV / Google TV over your home Wi-Fi — the same protocol
Google's own "Android TV Remote" app and the Google Home app use. No
Bluetooth HID (many phones, including MIUI/Xiaomi devices, don't support
acting as a Bluetooth HID peripheral), no ADB, no developer mode on the TV.

## How it works

1. **Discovery** — `TvDiscovery` browses mDNS for `_androidtvremote2._tcp`
   on the local network and lists found TVs.
2. **Pairing** (first time only) — `PairingClient` opens a TLS connection to
   the TV on port **6467**, presents a self-signed client certificate
   (`ClientIdentity`, generated once and reused forever), and runs the
   "Polo" handshake. The TV then shows a 6-character hex code; you type it
   into the app, which hashes it together with both certificates'
   public keys (`TlsSupport.computeSecret`) to prove the code was read off
   the actual screen.
3. **Remote control** — `RemoteSession` opens a second TLS connection on
   port **6466** (same client cert, so no re-pairing needed) and sends
   length-prefixed protobuf `RemoteMessage` key-press events.

The protobuf wire format is hand-written (`proto/Wire.kt`) rather than
generated via protoc, so there's no extra toolchain in the Gradle build —
the schemas were copied field-for-field from Google's own AOSP
`google-tv-pairing-protocol` (`polo.proto`) and the actively-maintained
`tronikos/androidtvremote2` library (`remotemessage.proto`), which is what
Home Assistant uses internally.

## Setup

1. Open the project root in Android Studio, let Gradle sync.
2. Run on a phone on **the same Wi-Fi network** as the TV.
3. Grant the "nearby devices" permission prompt (needed for mDNS discovery
   on Android 13+).
4. Wait for your TV to appear in the list, tap **Connect**.
5. First time: a dialog asks for the 6-character code the TV is now
   showing on screen. Type it in, tap Pair.
6. After that, reconnecting is instant — no code needed again, since the
   TV remembers this phone's certificate.

## Touchpad mode

This protocol has no "move cursor by X pixels" message — only discrete
key presses. So touchpad mode translates swipes into bursts of D-pad
key presses (the same trick most Wi-Fi remote apps use), not a true
free-moving pointer:

| Gesture | Action |
|---|---|
| 1-finger swipe | Repeated D-pad presses in that direction |
| 1-finger tap | OK (D-pad center) |
| 2-finger tap | Back |

## Known rough edges / what to check if pairing doesn't complete

This is a from-scratch Kotlin implementation of a reverse-engineered
protocol — the wire schemas are copied from authoritative sources, but the
exact **handshake sequencing** (especially right after the TLS connect on
port 6466) is the part most likely to need a tweak against a specific TV
brand's firmware:

- If pairing consistently fails at the `Options` exchange step, the TV may
  expect the server's `Options` reply to be inspected/matched rather than
  ignored (`PairingClient.runHandshakeUntilCodeNeeded`) — check Logcat for
  exactly which `readOuter()` call throws.
- If the remote channel connects but key presses don't register, the TV
  may expect `RemoteSetActive` sent proactively by the client rather than
  only `RemoteConfigure` — try calling `RemoteProto.setActive()` right
  after connecting in `RemoteSession.runSession()`.
- `RemoteConfigure.code1` is currently a placeholder value (`622`); if the
  TV rejects configuration, this is the first field worth experimenting
  with.

## Project structure

```
app/src/main/java/com/remotecontrol/tvhid/
  proto/Wire.kt             Minimal proto3 varint/length-delimited encoder+decoder
  proto/PoloMessages.kt     Pairing protocol messages (polo.proto)
  proto/RemoteMessages.kt   Remote-control protocol messages (remotemessage.proto)
  net/Identity.kt           Self-signed client certificate, generated once & persisted
  net/TlsSupport.kt         SSLContext + trust-on-first-use + pairing secret hash
  net/TvDiscovery.kt        mDNS discovery (_androidtvremote2._tcp)
  net/PairingClient.kt      Pairing handshake over TLS (port 6467)
  net/RemoteSession.kt      Persistent remote-control connection (port 6466)
  TouchpadView.kt           Gesture-to-D-pad-burst translation
  MainActivity.kt           UI wiring, permissions, pairing-code dialog
```
