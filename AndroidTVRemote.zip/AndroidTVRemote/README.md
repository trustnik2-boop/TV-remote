# TV Remote over Bluetooth HID (Android)

An Android app that turns your phone into a Bluetooth remote for Android TV —
D-pad, back/home, volume/media keys, **plus a laptop-style touchpad** for
full mouse control. It works by having the phone register itself with
Android's `BluetoothHidDevice` profile as a composite **keyboard + mouse +
consumer-control** device — the same way a physical Bluetooth remote/mouse
combo would appear to the TV. No IR blaster, no companion server, no root.

## How it works

- `HidRemoteManager` registers a custom HID report descriptor (keyboard,
  mouse, and an 8-bit consumer-control bitmap) via `BluetoothHidDevice`.
- `TouchpadView` is a custom `View` that turns 1-finger drag/tap and
  2-finger drag/tap into relative mouse-move / click / scroll HID reports.
- `MainActivity` wires D-pad and media buttons to keyboard/consumer reports,
  handles runtime Bluetooth permissions, and lets you pick a **bonded**
  device to connect to.

## Setup

1. Open the project root in Android Studio (Koala+ recommended).
2. Let Gradle sync — it will fetch AndroidX/Material dependencies.
3. Run on a phone with **Android 9 (API 28) or newer** (BluetoothHidDevice
   requires it).

## Pairing with your TV

1. On the phone, go to **Settings → Bluetooth** and pair with the TV the
   normal way (the TV needs to be discoverable, or already show up as a
   bonded device on the phone).
2. Open this app. Grant the Bluetooth permission prompt.
3. Pick the TV from the dropdown and tap **Connect**.
4. Once "Connected to <TV name>" shows, the D-pad/buttons and touchpad
   are live.

If the TV doesn't show a way to pair "as a remote," pair it as a normal
Bluetooth device first — once bonded, this app's `connect()` call
establishes the HID Device profile connection on top of that bond.

## Gestures (Touchpad mode)

| Gesture | Action |
|---|---|
| 1-finger drag | Move cursor |
| 1-finger tap | Left click |
| 2-finger tap | Right click / back |
| 2-finger vertical drag | Scroll |

Sensitivity is set in `TouchpadView.sensitivity` — increase it if the
cursor feels sluggish on a large TV screen.

## Known limitations / things to tune per TV

- **Home key**: mapped to the Consumer Page "AL Home" usage. Most Android
  TV / Google TV boxes honor it, but some third-party boxes don't expose a
  HID equivalent for Home — if it doesn't work on your device, remap the
  `btnHome` click handler to a different key or use a long-press-Back
  fallback.
- **Back key**: mapped to `Escape` on the keyboard page, which Android TV's
  input framework treats as Back. This is broadly reliable.
- Some TVs are picky about **SDP record fields** (`BluetoothHidDeviceAppSdpSettings`)
  — if pairing succeeds but the TV never shows input, try adjusting the
  `SUBCLASS1_COMBO` value or splitting keyboard/mouse into separate SDP
  registrations.
- This uses Bluetooth Classic HID (`BluetoothHidDevice`), not BLE HID —
  that matches how virtually all Android TV boxes expect a keyboard/mouse
  to connect.

## Project structure

```
app/src/main/java/com/remotecontrol/tvhid/
  HidUsage.kt          Key/consumer/mouse usage-code constants
  HidRemoteManager.kt  BluetoothHidDevice registration + report descriptor + senders
  TouchpadView.kt       Gesture-to-mouse-report translation
  MainActivity.kt       Permissions, device picker, UI wiring
```
